<?php
/**
 * BRT Tracking API Proxy - FTP/PHP Version
 * Sostituisce il server Node.js/Express per hosting su spazio FTP con PHP.
 * Carica questo file insieme ai file statici di dist/ nella root del tuo spazio FTP.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit();
}

$body = json_decode(file_get_contents('php://input'), true);

$parcelID  = isset($body['parcelID'])   ? trim($body['parcelID'])   : '';
$userID    = isset($body['userID'])     ? trim($body['userID'])     : '';
$password  = isset($body['password'])  ? trim($body['password'])   : '';
$useSandbox = isset($body['useSandbox']) ? (bool)$body['useSandbox'] : true;

if ($parcelID === '') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Il codice segnacollo (parcelID) è obbligatorio.']);
    exit();
}

$cleanParcelId = $parcelID;
$isNumericPattern = preg_match('/^\d{7,15}$/', $cleanParcelId);
$looksLikeRealId  = $isNumericPattern && strpos($cleanParcelId, '12345') !== 0;

// ─── 1. SOAP PUBLIC LOOKUP ─────────────────────────────────────────────────────
if (($useSandbox || !$userID || !$password) && $looksLikeRealId) {
    $soapResult = fetchSoapTracking($cleanParcelId);
    if ($soapResult !== null && $soapResult['success'] && count($soapResult['lista_eventi']) > 0) {
        echo json_encode($soapResult);
        exit();
    }
}

// ─── 2. DEMO / MOCK FALLBACK ───────────────────────────────────────────────────
if ($useSandbox || !$userID || !$password) {
    echo json_encode(generateFallbackTracking($cleanParcelId));
    exit();
}

// ─── 3. BRT REST API ──────────────────────────────────────────────────────────
$brtUrl = 'https://api.brt.it/rest/v1/tracking/parcelID/' . urlencode($cleanParcelId);
$ch = curl_init($brtUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
        'userID: ' . $userID,
        'password: ' . $password,
        'Accept: application/json',
    ],
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_SSL_VERIFYPEER => true,
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

$resJson = null;
if ($response !== false) {
    $resJson = json_decode($response, true);
}

$responseHasError = true;
if ($resJson) {
    $resBody = $resJson['parcelIDResult'] ?? $resJson['ttParcelIdResponse'] ?? $resJson;
    $checkCode = isset($resBody['executionMessage']['code'])
        ? (int)$resBody['executionMessage']['code']
        : (isset($resBody['code']) ? (int)$resBody['code'] : 0);
    $responseHasError = $checkCode < 0;
}

$isHttpError = $httpCode !== 200;

// ─── 4. SOAP FALLBACK se REST fallisce ────────────────────────────────────────
if (($isHttpError || $responseHasError || !$resJson) && $looksLikeRealId) {
    $soapResult = fetchSoapTracking($cleanParcelId);
    if ($soapResult !== null && $soapResult['success'] && count($soapResult['lista_eventi']) > 0) {
        echo json_encode($soapResult);
        exit();
    }
}

if (!$resJson) {
    $statusText = $curlError ?: "HTTP $httpCode";
    echo json_encode([
        'success'    => false, 'code' => -1, 'severity' => 'ERROR',
        'codeDesc'   => 'REST API Connection Failure',
        'message'    => "Impossibile connettersi all'API di BRT ($statusText). Verifica le credenziali o la raggiungibilità di api.brt.it",
        'parcelID'   => $cleanParcelId,
        'ragione_sociale' => '', 'indirizzo' => '', 'cap' => '', 'localita' => '',
        'sigla_provincia' => '', 'sigla_nazione' => '', 'referente_consegna' => '', 'telefono_referente' => '',
        'colli' => 0, 'peso_kg' => 0, 'riferimento_mittente_numerico' => 0, 'riferimento_mittente_alfabetico' => '',
        'data_cons_richiesta' => '', 'ora_cons_richiesta' => '', 'tipo_cons_richiesta' => '',
        'descrizione_cons_richiesta' => '', 'data_teorica_consegna' => '', 'ora_teorica_consegna_da' => '',
        'ora_teorica_consegna_a' => '', 'data_consegna_merce' => '', 'ora_consegna_merce' => '',
        'firmatario_consegna' => '', 'lista_eventi' => [],
    ]);
    exit();
}

echo json_encode(parseBrtResponse($resJson, $cleanParcelId));
exit();

// ═══════════════════════════════════════════════════════════════════════════════
// FUNZIONI
// ═══════════════════════════════════════════════════════════════════════════════

function fetchSoapTracking(string $shipmentId): ?array {
    $soapRequest = '<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:brt="http://brt_trackingbybrtshipmentid.wsbeans.iseries/">'
        . '<soapenv:Header/><soapenv:Body><brt:brt_trackingbybrtshipmentid><arg0>'
        . '<SPEDIZIONE_ANNO>0</SPEDIZIONE_ANNO>'
        . '<SPEDIZIONE_BRT_ID>' . htmlspecialchars($shipmentId, ENT_XML1) . '</SPEDIZIONE_BRT_ID>'
        . '<LINGUA_ISO639_ALPHA2>it</LINGUA_ISO639_ALPHA2>'
        . '</arg0></brt:brt_trackingbybrtshipmentid></soapenv:Body></soapenv:Envelope>';

    $ch = curl_init('https://wsr.brt.it:10052/web/BRT_TrackingByBRTshipmentIDService/BRT_TrackingByBRTshipmentID?wdsl');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $soapRequest,
        CURLOPT_HTTPHEADER     => ['Content-Type: text/xml; charset=utf-8'],
        CURLOPT_TIMEOUT        => 10,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $xml = curl_exec($ch);
    curl_close($ch);

    if (!$xml) return null;

    return parseSoapResponse($xml, $shipmentId);
}

function parseSoapResponse(string $xmlText, string $parcelID): array {
    $parseTag = function(string $tag) use ($xmlText): string {
        preg_match("/<{$tag}[^>]*>([^<]*)<\/{$tag}>/i", $xmlText, $m);
        return isset($m[1]) ? trim($m[1]) : '';
    };
    $parseTags = function(string $tag) use ($xmlText): array {
        preg_match_all("/<{$tag}[^>]*>([^<]*)<\/{$tag}>/i", $xmlText, $m);
        return array_map('trim', $m[1] ?? []);
    };

    $stato1    = $parseTag('STATO_SPED_PARTE1') ?: $parseTag('STATO_SPED_PARTE_1');
    $descStato = $parseTag('DESCRIZIONE_STATO_SPED_PARTE1') ?: $parseTag('DESCRIZIONE_STATO_SPED_PARTE_1');
    $descs     = $parseTags('DESCRIZIONE');
    $dates     = $parseTags('DATA');
    $times     = $parseTags('ORA');
    $branches  = $parseTags('FILIALE');
    $ids       = $parseTags('ID') ?: $parseTags('ID_EVENTO') ?: $parseTags('CODICE');

    $events = [];
    $max = max(count($descs), count($dates), count($times), count($branches));
    for ($i = 0; $i < $max; $i++) {
        $events[] = [
            'data'        => str_replace('.', '-', $dates[$i] ?? ''),
            'ora'         => $times[$i] ?? '',
            'id'          => $ids[$i] ?? 'EVT',
            'descrizione' => $descs[$i] ?? '',
            'filiale'     => $branches[$i] ?? '',
        ];
    }

    $isSuccess = $max > 0 || $stato1 !== '';

    return [
        'parcelID' => $parcelID, 'success' => $isSuccess,
        'code' => $isSuccess ? 0 : -1, 'severity' => 'INFO',
        'codeDesc' => $isSuccess ? 'SOAP Success' : 'No tracking found',
        'message'  => $descStato ?: ($isSuccess ? 'Spedizione tracciata via SOAP BRT.' : 'Spedizione non trovata.'),
        'ragione_sociale'    => $parseTag('RAGIONE_SOC_DEST') ?: $parseTag('RAGIONE_SOCIALE'),
        'indirizzo'          => $parseTag('VIA_DEST_RICEV') ?: $parseTag('INDIRIZZO_DEST'),
        'cap'                => $parseTag('CAP_DEST_RICEV') ?: $parseTag('CAP_DEST'),
        'localita'           => $parseTag('LOCALITA_DEST_RICEV') ?: $parseTag('LOCALITA_DEST'),
        'sigla_provincia'    => $parseTag('PROVINCIA_DEST_RICEV') ?: $parseTag('PROVINCIA_DEST'),
        'sigla_nazione'      => $parseTag('NAZIONE_DEST_RICEV') ?: 'IT',
        'referente_consegna' => '',
        'telefono_referente' => $parseTag('TELEFONO_DEST') ?: $parseTag('TELEFONO_REFERENTE'),
        'ragione_sociale_mittente' => $parseTag('RAGIONE_SOC_MITT') ?: $parseTag('MITTENTE'),
        'indirizzo_mittente'       => $parseTag('VIA_MITT') ?: $parseTag('INDIRIZZO_MITTENTE'),
        'cap_mittente'             => $parseTag('CAP_MITT') ?: $parseTag('CAP_MITTENTE'),
        'localita_mittente'        => $parseTag('LOCALITA_MITT') ?: $parseTag('LOCALITA_MITTENTE'),
        'sigla_provincia_mittente' => $parseTag('PROV_MITT') ?: $parseTag('SIGLA_PROV_MITTENTE'),
        'sigla_nazione_mittente'   => 'IT',
        'telefono_mittente'        => $parseTag('TELEFONO_MITT'),
        'colli'   => (int)($parseTag('NUMERO_COLLI') ?: $parseTag('COLLI') ?: 1),
        'peso_kg' => (float)str_replace(',', '.', $parseTag('PESO_SPEDIZIONE') ?: $parseTag('PESO') ?: '0'),
        'riferimento_mittente_numerico'   => (int)($parseTag('RIF_MITTENTE_NUM') ?: 0),
        'riferimento_mittente_alfabetico' => $parseTag('RIF_MITTENTE_ALF') ?: $parseTag('RIFERIMENTO_PARTNER_ESTERO'),
        'data_cons_richiesta' => '', 'ora_cons_richiesta' => '', 'tipo_cons_richiesta' => '',
        'descrizione_cons_richiesta' => '',
        'data_teorica_consegna'    => $parseTag('DATA_TEORICA_CONSEGNA'),
        'ora_teorica_consegna_da'  => $parseTag('ORA_CONSEGNA_DA'),
        'ora_teorica_consegna_a'   => $parseTag('ORA_CONSEGNA_A'),
        'data_consegna_merce'      => $parseTag('DATA_CONSEGNA_EFFETTIVA') ?: ($descs[0] === 'CONSEGNATA' ? ($dates[0] ?? '') : ''),
        'ora_consegna_merce'       => $parseTag('ORA_CONSEGNA_EFFETTIVA') ?: ($descs[0] === 'CONSEGNATA' ? ($times[0] ?? '') : ''),
        'firmatario_consegna'      => $parseTag('FIRMATARIO') ?: $parseTag('FIRMATARIO_CONSEGNA'),
        'lista_eventi'             => $events,
        'stato_sped_parte1'               => $stato1,
        'stato_sped_parte2'               => $parseTag('STATO_SPED_PARTE2'),
        'descrizione_stato_sped_parte1'   => $descStato,
        'descrizione_stato_sped_parte2'   => $parseTag('DESCRIZIONE_STATO_SPED_PARTE2'),
    ];
}

function parseBrtResponse(array $data, string $parcelID): array {
    $resBody = $data['parcelIDResult'] ?? $data['ttParcelIdResponse'] ?? $data;
    $bolla   = $resBody['bolla'] ?? $resBody;

    $code    = isset($resBody['executionMessage']['code'])
        ? (int)$resBody['executionMessage']['code']
        : (isset($resBody['code']) ? (int)$resBody['code'] : 0);
    $isOk    = $code >= 0;

    $dest = $bolla['destinatario'] ?? $resBody['destinatario'] ?? [];
    $mit  = $bolla['mittente']     ?? $resBody['mittente']     ?? [];
    $merc = $bolla['merce']        ?? $resBody['merce']        ?? [];
    $refs = $bolla['riferimenti']  ?? $resBody['riferimenti']  ?? [];
    $del  = $bolla['dati_consegna'] ?? $resBody['dati_consegna'] ?? [];

    $rawEvents = $bolla['lista_eventi'] ?? $resBody['lista_eventi'] ?? [];
    if (!is_array($rawEvents)) $rawEvents = $rawEvents ? [$rawEvents] : [];
    $events = [];
    foreach ($rawEvents as $item) {
        $ev = $item['evento'] ?? $item;
        $events[] = [
            'data'        => $ev['data'] ?? '',
            'ora'         => $ev['ora'] ?? '',
            'id'          => $ev['id'] ?? '',
            'descrizione' => $ev['descrizione'] ?? '',
            'filiale'     => $ev['filiale'] ?? '',
        ];
    }

    return [
        'parcelID' => $parcelID, 'success' => $isOk, 'code' => $code,
        'severity' => $resBody['severity'] ?? ($resBody['executionMessage']['severity'] ?? 'INFO'),
        'codeDesc' => $resBody['codeDesc'] ?? ($resBody['executionMessage']['codeDesc'] ?? ''),
        'message'  => $resBody['message']  ?? ($resBody['executionMessage']['message']  ?? ''),
        'ragione_sociale'    => $dest['ragione_sociale'] ?? '',
        'indirizzo'          => $dest['indirizzo'] ?? '',
        'cap'                => $dest['cap'] ?? '',
        'localita'           => $dest['localita'] ?? '',
        'sigla_provincia'    => $dest['sigla_provincia'] ?? '',
        'sigla_nazione'      => $dest['sigla_nazione'] ?? 'IT',
        'referente_consegna' => $dest['referente_consegna'] ?? '',
        'telefono_referente' => $dest['telefono_referente'] ?? '',
        'ragione_sociale_mittente' => $mit['ragione_sociale'] ?? '',
        'indirizzo_mittente'       => $mit['indirizzo'] ?? '',
        'cap_mittente'             => $mit['cap'] ?? '',
        'localita_mittente'        => $mit['localita'] ?? '',
        'sigla_provincia_mittente' => $mit['sigla_provincia'] ?? '',
        'sigla_nazione_mittente'   => $mit['sigla_nazione'] ?? 'IT',
        'telefono_mittente'        => $mit['telefono'] ?? '',
        'colli'   => isset($merc['colli'])   ? (int)$merc['colli']   : 0,
        'peso_kg' => isset($merc['peso_kg']) ? (float)$merc['peso_kg'] : 0.0,
        'riferimento_mittente_numerico'   => isset($refs['riferimento_mittente_numerico']) ? (int)$refs['riferimento_mittente_numerico'] : 0,
        'riferimento_mittente_alfabetico' => $refs['riferimento_mittente_alfabetico'] ?? '',
        'data_cons_richiesta'      => $del['data_cons_richiesta'] ?? '',
        'ora_cons_richiesta'       => $del['ora_cons_richiesta'] ?? '',
        'tipo_cons_richiesta'      => $del['tipo_cons_richiesta'] ?? '',
        'descrizione_cons_richiesta' => $del['descrizione_cons_richiesta'] ?? '',
        'data_teorica_consegna'    => $del['data_teorica_consegna'] ?? '',
        'ora_teorica_consegna_da'  => $del['ora_teorica_consegna_da'] ?? '',
        'ora_teorica_consegna_a'   => $del['ora_teorica_consegna_a'] ?? '',
        'data_consegna_merce'      => $del['data_consegna_merce'] ?? '',
        'ora_consegna_merce'       => $del['ora_consegna_merce'] ?? '',
        'firmatario_consegna'      => $del['firmatario_consegna'] ?? '',
        'lista_eventi'             => $events,
        'stato_sped_parte1'               => $resBody['stato_sped_parte1'] ?? $bolla['stato_sped_parte1'] ?? '',
        'stato_sped_parte2'               => $resBody['stato_sped_parte2'] ?? $bolla['stato_sped_parte2'] ?? '',
        'descrizione_stato_sped_parte1'   => $resBody['descrizione_stato_sped_parte1'] ?? $bolla['descrizione_stato_sped_parte1'] ?? '',
        'descrizione_stato_sped_parte2'   => $resBody['descrizione_stato_sped_parte2'] ?? $bolla['descrizione_stato_sped_parte2'] ?? '',
        'originalPayload' => $data,
    ];
}

function generateFallbackTracking(string $parcelID): array {
    $mockShipments = [
        '08459100301718' => [
            'success' => true, 'code' => 0, 'severity' => 'INFO',
            'codeDesc' => 'Spedizione consegnata con successo',
            'message'  => 'La spedizione è stata consegnata.',
            'ragione_sociale' => 'ABATE GIORGIO', 'indirizzo' => 'VIA FRANCESCO REDI 58',
            'cap' => '93012', 'localita' => 'GELA', 'sigla_provincia' => 'CL',
            'sigla_nazione' => 'IT', 'referente_consegna' => 'ABATE GIORGIO',
            'telefono_referente' => '+393495806585',
            'ragione_sociale_mittente' => 'ARLIA SRL', 'indirizzo_mittente' => 'VIA FRAILLITI SNC',
            'cap_mittente' => '87030', 'localita_mittente' => 'LONGOBARDI',
            'sigla_provincia_mittente' => 'CS', 'sigla_nazione_mittente' => 'IT',
            'telefono_mittente' => '+39098278131',
            'colli' => 1, 'peso_kg' => 0,
            'riferimento_mittente_numerico' => 88151, 'riferimento_mittente_alfabetico' => 'brt-marco2',
            'data_cons_richiesta' => '16.06.2026', 'ora_cons_richiesta' => 'Qualsiasi ora',
            'tipo_cons_richiesta' => 'Standard', 'descrizione_cons_richiesta' => 'Nessun vincolo inserito',
            'data_teorica_consegna' => '16.06.2026', 'ora_teorica_consegna_da' => '08:30',
            'ora_teorica_consegna_a' => '18:30', 'data_consegna_merce' => '16.06.2026',
            'ora_consegna_merce' => '15:40', 'firmatario_consegna' => 'ABATE GIORGIO',
            'stato_sped_parte1' => 'CONSEGNATA', 'stato_sped_parte2' => 'OK',
            'descrizione_stato_sped_parte1' => 'Spedizione consegnata con successo',
            'descrizione_stato_sped_parte2' => 'Consegnata',
            'lista_eventi' => [
                ['data' => '16.06.2026', 'ora' => '18:47:25', 'id' => 'POD', 'descrizione' => 'Abbiamo ricevuto la prova di consegna', 'filiale' => ''],
                ['data' => '16.06.2026', 'ora' => '15:40:10', 'id' => 'DEL', 'descrizione' => 'La spedizione è stata consegnata', 'filiale' => 'Caltanissetta, IT'],
                ['data' => '16.06.2026', 'ora' => '10:39:59', 'id' => 'O4D', 'descrizione' => 'La spedizione è in consegna', 'filiale' => 'Caltanissetta, IT'],
                ['data' => '16.06.2026', 'ora' => '08:32:45', 'id' => 'ARR', 'descrizione' => 'La spedizione è presso la filiale di consegna', 'filiale' => 'Caltanissetta, IT'],
            ],
        ],
        'BRT-ERROR' => [
            'success' => false, 'code' => -12, 'severity' => 'ERROR',
            'codeDesc' => 'SPEDIZIONE NON TROVATA',
            'message'  => 'Il segnacollo inserito non corrisponde a nessuna spedizione attiva.',
            'ragione_sociale' => '', 'indirizzo' => '', 'cap' => '', 'localita' => '',
            'sigla_provincia' => '', 'sigla_nazione' => '', 'referente_consegna' => '', 'telefono_referente' => '',
            'colli' => 0, 'peso_kg' => 0, 'riferimento_mittente_numerico' => 0,
            'riferimento_mittente_alfabetico' => '',
            'data_cons_richiesta' => '', 'ora_cons_richiesta' => '', 'tipo_cons_richiesta' => '',
            'descrizione_cons_richiesta' => '', 'data_teorica_consegna' => '',
            'ora_teorica_consegna_da' => '', 'ora_teorica_consegna_a' => '',
            'data_consegna_merce' => '', 'ora_consegna_merce' => '', 'firmatario_consegna' => '',
            'lista_eventi' => [],
        ],
    ];

    $normId = strtoupper(trim($parcelID));
    if (isset($mockShipments[$normId])) {
        return array_merge(['parcelID' => $parcelID], $mockShipments[$normId]);
    }

    $isDelivered = str_starts_with($normId, 'BRT') || (strlen($normId) % 2 === 0);
    $isTransit   = str_contains($normId, 'TR')    || (strlen($normId) % 3 === 1);

    if ($isDelivered) {
        return [
            'parcelID' => $parcelID, 'success' => true, 'code' => 0, 'severity' => 'INFO',
            'codeDesc' => 'Esito Positivo', 'message' => 'Spedizione recapitata regolarmente.',
            'ragione_sociale' => "Ditta Automatica SpA ($parcelID)", 'indirizzo' => 'Viale dei Ciliegi, 204',
            'cap' => '00185', 'localita' => 'Roma', 'sigla_provincia' => 'RM', 'sigla_nazione' => 'IT',
            'referente_consegna' => 'Dott. Giovanni Verga', 'telefono_referente' => '+39 06 11223344',
            'colli' => 2, 'peso_kg' => 14.8,
            'riferimento_mittente_numerico' => 554321, 'riferimento_mittente_alfabetico' => 'DYN-' . substr($normId, -4),
            'data_cons_richiesta' => '2026-06-16', 'ora_cons_richiesta' => '10:00',
            'tipo_cons_richiesta' => 'standard', 'descrizione_cons_richiesta' => 'Suonare al civico 10 se cancello chiuso',
            'data_teorica_consegna' => '2026-06-17', 'ora_teorica_consegna_da' => '10:00',
            'ora_teorica_consegna_a' => '12:00', 'data_consegna_merce' => '2026-06-17',
            'ora_consegna_merce' => '11:22', 'firmatario_consegna' => 'G. Verga (Portineria)',
            'stato_sped_parte1' => 'CONSEGNATA', 'stato_sped_parte2' => 'OK',
            'descrizione_stato_sped_parte1' => 'Consegnata', 'descrizione_stato_sped_parte2' => 'Consegna completata',
            'lista_eventi' => [
                ['data' => '2026-06-17', 'ora' => '11:22', 'id' => 'DEL', 'descrizione' => 'MERCE CONSEGNATA CON SUCCESSO', 'filiale' => 'ROMA LAURENTINA'],
                ['data' => '2026-06-17', 'ora' => '07:55', 'id' => 'O4D', 'descrizione' => 'COLLI IN CONSEGNA CON AUTISTA', 'filiale' => 'ROMA LAURENTINA'],
                ['data' => '2026-06-17', 'ora' => '02:14', 'id' => 'ARR', 'descrizione' => 'ARRIVATA PRESSO FILIALE DI ARRIVO', 'filiale' => 'ROMA LAURENTINA'],
                ['data' => '2026-06-16', 'ora' => '21:30', 'id' => 'HUB', 'descrizione' => 'IN VIAGGIO TRA CENTRI OPERATIVI', 'filiale' => 'MILANO HUB'],
                ['data' => '2026-06-16', 'ora' => '18:05', 'id' => 'PUG', 'descrizione' => 'ACCETTATA E DOCUMENTATA', 'filiale' => 'MILANO BOVISA'],
            ],
        ];
    } elseif ($isTransit) {
        return [
            'parcelID' => $parcelID, 'success' => true, 'code' => 0, 'severity' => 'INFO',
            'codeDesc' => 'In Transito', 'message' => 'ID collo localizzato sulla linea principale di smistamento.',
            'ragione_sociale' => "Studio Architettura Paladini ($parcelID)", 'indirizzo' => 'Piazza Garibaldi, 12',
            'cap' => '70122', 'localita' => 'Bari', 'sigla_provincia' => 'BA', 'sigla_nazione' => 'IT',
            'referente_consegna' => 'Ing. Paola Paladini', 'telefono_referente' => '+39 080 334455',
            'colli' => 1, 'peso_kg' => 3.1,
            'riferimento_mittente_numerico' => 981240, 'riferimento_mittente_alfabetico' => 'BRT-SHIP-' . substr($normId, -3),
            'data_cons_richiesta' => '', 'ora_cons_richiesta' => '', 'tipo_cons_richiesta' => 'standard',
            'descrizione_cons_richiesta' => '', 'data_teorica_consegna' => '2026-06-18',
            'ora_teorica_consegna_da' => '09:00', 'ora_teorica_consegna_a' => '18:00',
            'data_consegna_merce' => '', 'ora_consegna_merce' => '', 'firmatario_consegna' => '',
            'stato_sped_parte1' => 'IN VIAGGIO', 'stato_sped_parte2' => 'IN ORARIO',
            'descrizione_stato_sped_parte1' => 'Spedizione in viaggio', 'descrizione_stato_sped_parte2' => 'Regolare instradamento',
            'lista_eventi' => [
                ['data' => '2026-06-17', 'ora' => '04:12', 'id' => 'HUB', 'descrizione' => 'IN COMMUTAZIONE HUB LOGISTICO', 'filiale' => 'ANCONA HUB'],
                ['data' => '2026-06-16', 'ora' => '19:00', 'id' => 'DEP', 'descrizione' => 'PARTENZA DA FILIALE ACCETTAZIONE', 'filiale' => 'BOLOGNA ROVERI'],
                ['data' => '2026-06-16', 'ora' => '14:22', 'id' => 'PUG', 'descrizione' => 'CARICATO ALLA PARTENZA', 'filiale' => 'BOLOGNA ROVERI'],
            ],
        ];
    } else {
        return [
            'parcelID' => $parcelID, 'success' => false, 'code' => -10, 'severity' => 'ERROR',
            'codeDesc' => 'Spedizione Non Trovata',
            'message'  => "Il segnacollo $parcelID non è stato trovato. Verificare la digitazione e riprovare.",
            'ragione_sociale' => '', 'indirizzo' => '', 'cap' => '', 'localita' => '',
            'sigla_provincia' => '', 'sigla_nazione' => '', 'referente_consegna' => '', 'telefono_referente' => '',
            'colli' => 0, 'peso_kg' => 0, 'riferimento_mittente_numerico' => 0,
            'riferimento_mittente_alfabetico' => '',
            'data_cons_richiesta' => '', 'ora_cons_richiesta' => '', 'tipo_cons_richiesta' => '',
            'descrizione_cons_richiesta' => '', 'data_teorica_consegna' => '',
            'ora_teorica_consegna_da' => '', 'ora_teorica_consegna_a' => '',
            'data_consegna_merce' => '', 'ora_consegna_merce' => '', 'firmatario_consegna' => '',
            'lista_eventi' => [],
        ];
    }
}
