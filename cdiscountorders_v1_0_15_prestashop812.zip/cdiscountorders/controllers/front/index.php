<?php

header('Location: ../../');
exit;
